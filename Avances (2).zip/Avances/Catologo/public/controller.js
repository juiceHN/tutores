var app = angular.module("myApp", []);
app.controller("AppCtrl", function($scope) {

	tutor1 = {
		nombre: 'Fernando Ramos',
		correo: 'f.Ramos@tutorGT.com',
		telefono: '(502)4567-8892',
		materias: 'Modelos Matematicos, Fisica I, POO, Python'
	};
	tutor2 = {
		nombre: 'Maria Kuri',
		correo: 'm.Kuri@tutorGT.com',
		telefono: '(502)3019-1231',
		materias: 'Ciencias de la vida, Fisica II, Expresion Oral, Calculo I'
	};
	tutor3 = {
		nombre: 'Rob Robbinson',
		correo: 'r.Robbinson@tutorGT.com',
		telefono: '(503)1231-7513',
		materias: 'Arduino, Mate Discreta I, Ecuaciones Diferenciales'
	};
	
	tutor4 = {
		nombre: 'tutorPrueba',
		correo: 'tutorPrueba@tutorGT.com',
		telefono: '(503)1234-5678',
		materias: 'Ingenieria de Software'
	};

	var contactlist = [tutor1, tutor2, tutor3, tutor4];
	$scope.contactlist = contactlist;

});